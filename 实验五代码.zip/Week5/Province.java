package Week5;

public class Province {
	String name;
	int sum;
	
	Province(){
		name = null;
		sum = 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}
}
