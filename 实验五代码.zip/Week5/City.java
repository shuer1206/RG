package Week5;

public class City {
	String name;
	String province;
	int num;
	
	City(){
		name=null;
		province=null;
		num=0;
	}
}
